
Please visit
<https://icefall.readthedocs.io/en/latest/recipes/aishell/tdnn_lstm_ctc.html>
for how to run this recipe.
