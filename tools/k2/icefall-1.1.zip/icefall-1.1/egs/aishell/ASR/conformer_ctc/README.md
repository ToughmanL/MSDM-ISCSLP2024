
Please visit
<https://icefall.readthedocs.io/en/latest/recipes/aishell/conformer_ctc.html>
for how to run this recipe.
