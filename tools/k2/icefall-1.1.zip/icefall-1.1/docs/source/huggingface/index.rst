Huggingface
===========

This section describes how to find pre-trained models.
It also demonstrates how to try them from within your browser
without installing anything by using
`Huggingface spaces <https://huggingface.co/spaces/k2-fsa/automatic-speech-recognition>`_.

.. toctree::
   :maxdepth: 2

   pretrained-models
   spaces
