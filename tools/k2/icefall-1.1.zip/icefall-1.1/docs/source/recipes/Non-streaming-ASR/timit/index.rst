TIMIT
=====

.. toctree::
   :maxdepth: 1

   tdnn_ligru_ctc
   tdnn_lstm_ctc
