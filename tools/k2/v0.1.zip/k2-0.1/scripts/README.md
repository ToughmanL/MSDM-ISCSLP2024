
## googletest.cfg

It is downloaded from https://github.com/danmar/cppcheck/blob/master/cfg/googletest.cfg
