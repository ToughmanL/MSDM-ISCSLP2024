.. k2 documentation master file, created by
   sphinx-quickstart on Fri Oct  2 21:03:36 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

K2 Documentation
================

.. toctree::
   :maxdepth: 2
   :caption: Contents:


.. toctree::
   :maxdepth: 2
   :caption: Python API

   python_api/array.rst
   python_api/fsa.rst
   python_api/symbol_table.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
