k2.array
--------

.. currentmodule:: k2

.. autoclass:: Array
    :members:
    :special-members:
    :private-members:

