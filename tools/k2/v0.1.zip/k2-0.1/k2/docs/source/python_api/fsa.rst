k2.fsa
------

.. currentmodule:: k2

.. autoclass:: Fsa
    :members:
    :special-members:
    :private-members:
