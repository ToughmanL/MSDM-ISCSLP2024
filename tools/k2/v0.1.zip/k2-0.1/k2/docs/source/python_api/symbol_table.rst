k2.symbol_table
---------------

.. currentmodule:: k2

.. autoclass:: SymbolTable
    :members:
    :special-members:
    :private-members:

