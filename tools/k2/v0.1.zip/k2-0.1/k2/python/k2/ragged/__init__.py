from .ops import index

__all__ = ['index']
